# Samsung A35 Theme Pro

A modern Android app showcasing Samsung A35's One UI design with Material 3 and Jetpack Compose.

## Features
- Material 3 Design System
- Jetpack Compose UI
- Samsung One UI inspired colors
- Dark/Light theme support
- GitHub Actions CI/CD

## Build Instructions

### Local Build
```bash
# Clone repository
git clone <repo-url>
cd SamsungThemePro

# Make gradlew executable
chmod +x gradlew

# Build the project
./gradlew build

# Build debug APK
./gradlew assembleDebug
```